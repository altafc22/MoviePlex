package gq.altafchaudhari.www.movieplex;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SelectTimingAndSeatActivity extends AppCompatActivity {

    TextView movie_name,theater_name,theater_city;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_timing_and_seat);

        movie_name = findViewById(R.id.movie_title);
        theater_name = findViewById(R.id.theater_name);
        theater_city = findViewById(R.id.theater_city);

        Intent getExtra =  getIntent();
        movie_name.setText(getExtra.getExtras().getString("movie_name",null));
        theater_name.setText(getExtra.getExtras().getString("theater_name",null));
        theater_city.setText(getExtra.getExtras().getString("theater_city",null));
    }
}
