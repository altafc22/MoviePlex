package gq.altafchaudhari.www.movieplex;

import android.app.Application;
import android.content.Context;

public class MyApplication extends Application {
    public String SP_NAME = "movieplex_sp";
}
