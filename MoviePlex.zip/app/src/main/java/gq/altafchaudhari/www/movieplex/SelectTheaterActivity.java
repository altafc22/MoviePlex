package gq.altafchaudhari.www.movieplex;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import gq.altafchaudhari.www.movieplex.adapter.TheaterAdapter;
import gq.altafchaudhari.www.movieplex.model.Theater;

public class SelectTheaterActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    TextView movie_name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_theater);
        changeStatusBarColor();
        movie_name = findViewById(R.id.movie_title);
        recyclerView = findViewById(R.id.recycler_view);

        Intent getExtra =  getIntent();
        movie_name.setText(getExtra.getExtras().getString("movie_name",null));
        loadData();

    }


    public void loadData()
    {
        TheaterAdapter myAdapter;
        List<Theater> theater ;
        theater = new ArrayList<>();
        ProgressDialog mProgress;
        mProgress = new ProgressDialog(getBaseContext());
        mProgress.setCancelable(false);
        mProgress.setIndeterminate(true);
        //mProgress.show();
        String movie_name_text =movie_name.getText().toString();
        theater.add(new Theater(movie_name_text,"INOX Reliance","Aurangabad",R.id.theater_image));
        theater.add( new Theater(movie_name_text,"INOX Tapadia","Aurangabad",R.id.theater_image));
        myAdapter = new TheaterAdapter(getBaseContext(), theater);
        recyclerView.setLayoutManager(new LinearLayoutManager(getBaseContext(),1,false));
        recyclerView.setAdapter(myAdapter);
        mProgress.dismiss();
    }

    /**
     * Making notification bar and bottom bar transparent
     */
    private void changeStatusBarColor() {


        //change notification icon color...
        View yourView = findViewById(R.id.splash_layout);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (yourView != null) {
                yourView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }
        //If you want to reset the changes, clear the flag like this:
        //yourView.setSystemUiVisibility(0);
        //change notification icon color end ...


        // Making notification bar transparent
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        // making notification bar transparent

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        }
        // making notification bar transparent end .....


        /*//change bottom bar to transperen....
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow(); // in Activity's onCreate() for instance
            w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }
        //to use any drawable add this two lines in style xml
        //<item name="android:windowDrawsSystemBarBackgrounds">true</item>
        //<item name="android:statusBarColor">@color/primary_dark</item>

        //change bottom bar to transperen end....
        */

    }
}
