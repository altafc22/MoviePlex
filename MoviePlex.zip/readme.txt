Movie plex 


Modules complted till now

Ui design for
1.splash screen(Activity)
2.login screen (Activity)
3.movies (fragment)
4.movie details (Activity)
5.profile page (fragment)


Prerequisites: Internet Conntectivity to load data from API

1. Login with Facebook
2. Movies (Release and Upcoming) used recyclerview to load data from TMDB API
3. Movie Details like (movie verview, rating etc.)
4. Select Theater (added two dummy theater using TheaterAdapter)
5. Profile Page (profile data from facebook)

Modules Remaining 
1. Seat Selection And Show Timing Selection Activity
2. Movie Ticket Generation with QR Code
3. Payment Activity (Payment Gateway)  
4. Also Show Trailers at the top of Movie Fragment 